<?php
#  Version 2.3.0
$lang['theme_style']                            = 'Kiểu giao diện';
$lang['settings_fb']                            = 'Quản lý Fanpage';
$lang['fanpage_fb']                             = 'Fanpage facebook';
