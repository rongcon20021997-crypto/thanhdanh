<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Messager extends AdminController
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('messager_model');
    }
    public function index()
    {
        if(!empty($_COOKIE['access_token_page_active']))
        {
            $data['title']  =   'Quản lý tin nhắn Fanpage Facebook';

            $VersionAppFB = get_option('VersionAppFB');
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://graph.facebook.com/".$VersionAppFB."/".$_COOKIE['page_active']."/conversations?access_token=".$_COOKIE['access_token_page_active'].'&fields=updated_time,senders&limit=500&suppress_http_code=1',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "GET",
                CURLOPT_HTTPHEADER => array(
                    "Accept: */*",
                    "Cache-Control: no-cache",
                    "Connection: keep-alive",
                    "Content-Type: application/json"
                ),
            ));

            $response = curl_exec($curl);
            $data_messager = curl_error($curl);

            curl_close($curl);
            $kt_data = json_decode($response);
            if(empty($kt_data->error->code))
            {
                $data['list_data'] = $response;
                $this->load->view('messagers/manage/manage', $data);
            }
            else
            {
                redirect('admin/messager/login');
            }
        }
        else
        {
            redirect('admin/messager/login');
        }
    }
    public function login()
    {
        $data['title']  =   'Đăng nhập FB';
        $this->load->view('messagers/login', $data);
    }
    /*
     * LẤY NỘI DUNG TIN NHẮN CUỘC TRÒ CHUYỆN
     */
    public function getJson_message()
    {
        $id = $this->input->get('id');
        if(!empty($id))
        {
            if(!empty($_COOKIE['access_token_page_active'])) {
                $curl = curl_init();
                curl_setopt_array($curl, array(
                    CURLOPT_URL => "https://graph.facebook.com/v3.1/" . $id . "/messages?access_token=" . $_COOKIE['access_token_page_active'] . "&fields=message,from,to,created_time,tags,attachments&limit=16&pretty=0&suppress_http_code=1",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER => array(
                        "Accept: */*",
                        "Cache-Control: no-cache",
                        "Connection: keep-alive",
                        "Content-Type: application/json"
                    ),
                ));

                $response = curl_exec($curl);
                $data_messager = curl_error($curl);
                curl_close($curl);
                $data['message'] = $response;
                $data['chat_area'] = true;
                $data['id_chat'] = $id;
                $this->load->view('messagers/manage/mid', $data);
            }
            else
            {
                redirect('messager/login');
            }
        }
    }


    /*
    *
    * Upload để gửi file từ PC
    */
    public function uploadfilepc()
    {
        if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '' && !empty($this->input->post('userid')))
        {
            $userid = $this->input->post('userid');
            if (!file_exists(FCPATH . 'uploads/Messager')) {
                mkdir(FCPATH . 'uploads/Messager');
                fopen(FCPATH . 'uploads/Messager' . '/index.html', 'w');
            }
            $path        = FCPATH . 'uploads/Messager' . '/'.$userid;
            $tmpFilePath = $_FILES['file']['tmp_name'];
            if (!empty($tmpFilePath) && $tmpFilePath != '') {
                $path_parts         = pathinfo($_FILES["file"]["name"]);
                $extension          = $path_parts['extension'];
                $extension = strtolower($extension);
                $allowed_extensions = array(
                    'jpg',
                    'jpeg',
                    'png'
                );
                if (!in_array($extension, $allowed_extensions)) {
                    echo json_encode(array('success' => false));die();
                }
                if (!file_exists($path)) {
                    mkdir($path);
                    fopen($path . '/index.html', 'w');
                }
                $_FILES["file"]["name"] = time().'_'.$_FILES["file"]["name"];
                $filename    = unique_filename($path, $_FILES["file"]["name"]);
                $newFilePath = $path . '/' . $filename;
                if(move_uploaded_file($tmpFilePath, $newFilePath))
                {
                    echo json_encode(array('success' => true,'name' => $filename, 'url' => base_url('uploads/Messager/'.$userid.'/'.$filename), 'newfile' => $newFilePath));die();
                }
            }
        }
        echo json_encode(array('success' => false));die();
    }
    /*
    *
    *   Xóa file khi gửi xong tin nhắn
    *
    */

    public function deleteFile()
    {
        if(!empty($this->input->post('url')))
        {
            unlink($this->input->post('url'));
        }
    }


















    //hau
    public function find_uid_facebook($id_facebook = NULL)
    {
        $facebook = $this->messager_model->find_user_facebook($id_facebook);
        $ckeck_sales = false;
        if($facebook)
        {
            $ckeck_sales = $this->messager_model->get_sale_client($facebook->userid);
            // $ckeck_sales = $this->messager_model->find_user_sales($facebook->userid);
        }
        $data['facebook']=$facebook;
        $data['ckeck_sales']=$ckeck_sales;
        echo json_encode($data);
    }
    public function find_name_phone()
    {
        $data = $this->input->post();
        echo json_encode($this->messager_model->find_name_phone($data));
    }
    public function add_profile()
    {
        $data = $this->input->post();
        $ckeck = $this->messager_model->find_user_facebook($data['id_facebook']);
        if(!empty($ckeck))
        {
            $this->messager_model->update_profile($data, $ckeck->userid);
            echo json_encode(array(
                                    'message'       => 'Cập nhật khách hàng thành công',
                                    'alert_type'    =>  'success'
                            ));die;
        }
        else
        {   
            if(!empty($data['client_id']))
            {
                $this->messager_model->update_profile($data, $data['client_id']);
                echo json_encode(array(
                            'message' => 'Cập nhật khách hàng thành công',
                            'alert_type'=>'success'
                        ));die;
            }
            else
            {
                $id = $this->messager_model->add_profile($data);
                if(!empty($id))
                {
                    echo json_encode(array(
                                            'message'       => 'Thêm khách hàng thành công',
                                            'alert_type'    =>  'success'
                                     ));die;
                }
            }
        }
    }
    public function get_sale_client($userid = '')
    {
        echo json_encode($this->messager_model->get_sale_client($userid));die();
    }
}

